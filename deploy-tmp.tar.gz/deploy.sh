#!/bin/bash
# ai-sandbox 一键部署脚本（本地执行）

set -e

SERVER_IP="162.14.79.120"
PORT="4000"
SERVER_USER="ubuntu"
NAME="ai-sandbox"
SSH_KEY="$HOME/.ssh/id_autologin"
REMOTE_DIR="/home/ubuntu/$NAME"

echo "=== $NAME 部署脚本 ==="

# 前置检查
if [ ! -f "$SSH_KEY" ]; then
	echo "错误：SSH 密钥不存在: $SSH_KEY"
	exit 1
fi

# 使用 rsync 部署：自动排除不需要的目录，并同步删除云端旧文件
echo "[1/2] 同步文件到服务器..."
rsync -avz --delete \
	--exclude 'node_modules' \
	--exclude '.git' \
	--exclude '*.log' \
	--exclude 'dist' \
	--exclude '.env' \
	-e "ssh -i $SSH_KEY" \
	./ "$SERVER_USER@$SERVER_IP:$REMOTE_DIR/"

# 重启 Nginx
echo "[2/2] 重启 Nginx..."
ssh -i "$SSH_KEY" "$SERVER_USER@$SERVER_IP" "sudo systemctl restart nginx"

echo ""
echo "=== 部署完成！访问 http://$SERVER_IP:$PORT ==="
